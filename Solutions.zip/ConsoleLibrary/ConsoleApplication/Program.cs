﻿using ConsoleLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            LibraryGoodness lg = new LibraryGoodness();
            Console.WriteLine($"The results are : {lg.Add(1, 2)}");
            Console.ReadKey();
        }
    }
}
