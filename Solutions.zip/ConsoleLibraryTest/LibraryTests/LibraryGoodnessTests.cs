﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleLibrary;

namespace LibraryTests
{
    //[TestClass]
    //public class LibraryGoodnessTests
    //{
    //    [TestMethod]
    //    public void TestAddOnePlusTwoEqualsThree()
    //    {
    //        LibraryGoodness lg = new LibraryGoodness();
    //        Assert.AreEqual(3, lg.Add(1, 2));
    //    }
    //}
}
